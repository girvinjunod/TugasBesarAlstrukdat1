Cara menjalankan program:
1. Buka folder src/main.
2. Compile dengan perintah berikut.
gcc main.c mainphase.c prepphase.c  ../graph/graph.c ../jam/jam.c ../listarray/listarray.c ../listlinier/listlinier.c ../material/material.c ../point/point.c ../stack/stack.c  ../wahana/wahana.c ../tree/tree.c ../mesinkata/mesinkata.c ../mesinkata/mesinkar.c ../queue/prioqueuePengunjung.c ../pengunjung/pengunjung.c ../map/map.c -o main
3. jalankan main.exe